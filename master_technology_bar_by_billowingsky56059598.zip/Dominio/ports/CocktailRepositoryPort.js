class CocktailRepositoryPort {
  async getAllCocktails() {
    throw new Error('Method not implemented');
  }
  
  async getCocktailById(id) {
    throw new Error('Method not implemented');
  }
}

export default CocktailRepositoryPort;

