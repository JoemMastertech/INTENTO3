class FoodRepositoryPort {
  async getAllFoods() {
    throw new Error('Method not implemented');
  }
  
  async getFoodsByCategory(category) {
    throw new Error('Method not implemented');
  }
  
  async getFoodById(id) {
    throw new Error('Method not implemented');
  }
}

export default FoodRepositoryPort;

